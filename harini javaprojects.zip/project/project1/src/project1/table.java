package project1;

public class table {
	public static void main(String aa[])
    {
		int num = 5;
		int i = 1;
		do {
			System.out.println(num*i);
			i++;
		}
		while(i<=10);
    }
}
