package project1;

public class factwhile {
	public static void main(String aa[])
    {
		int fact=1;  
		  int i = 1;
		  int num = 4;
		  do {    
			  fact=fact*i;
			  i++;
		 }
		  while(i<=num);
			  System.out.println("factorial of a number is" +fact);  
		  }
    
		}  

