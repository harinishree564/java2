package project1;

public class fibwhile {
	public static void main(String aa[])
	{

	int count= 20,n1=0,n2=1;
	System.out.println("Fibonacci Series are: "+count+" numbers:");
	for(int k=1;k<=count;++k) {
	System.out.println(n1+ "");
	int sumOfPrevTwo = n1 + n2;
	n1 = n2;
	n2 = sumOfPrevTwo;
	}
}
}