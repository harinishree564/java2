package project1;

public class student {
	​String name;

		student(String name){
		this.name=name;
		System.out.println("The name of the Student is "+name);
		}
		
		student(){
		System.out.println("The name of the Student is unknown ");
		}
		}
	