package project2;

public class value {
	public static void main(String[] args)
	   {
	     for(int i=65; i<=90; i++)
	     {
	    	 System.out.println("the ascii value of" + (char)i + " = " +i);
	     }
}
}