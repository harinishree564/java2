package project1;

public class test {
	public static void main(String a[]) {
		
	System.out.print ("hello");
	String name = "harini";
	int age = 25;
	System.out.println("my name is "+name+" ");
	System.out.println("my age is "+age+" ");

}
}