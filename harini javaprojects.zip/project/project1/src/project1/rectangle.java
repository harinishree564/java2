package project1;

public class rectangle {
	public static void main(String[] args) {
		int l=4,b=6, area_rectangle;
		area_rectangle= l* b;
		System.out.println("the area of rectangle is: " +area_rectangle);
		
	//circle	
	int radius=90;
	double area_circle;
	area_circle= (radius*radius)*Math.PI;
	System.out.println("the area of rectangle is: " +area_circle);
		
	//square
	int s=10, area_square=s*s;
	System.out.println("the area of rectangle is: " +area_square);
	}
}

