package project1;

public class greater {
	public static void main(String aa[])
    {
     
  int num1=12;
  int num2=24;
  int num3=30;
	if (num1 > num2)
		   if (num1 > num3)
		    System.out.println("The greatest: " + num1);
		   
		  if (num2 > num1)
		   if (num2 > num3)
		    System.out.println("The greatest: " + num2);
		   
		  if (num3 > num1)
		   if (num3 > num2)
		    System.out.println("The greatest: " + num3);
    }
	
}
