package project1;

import java.util.Scanner;

public class sum100method {
	public static void main (String args[]){
	int i=0;
	
	int sum=1;
		for(i=1;i<=100;i++);
		sum = sum + i;
	
		System.out.print("the sum of  first 100 number is " +sum);	
		
}
	
}