package project2;

public class catchtry {
	


	    public static void main(String aa[])
	    {
	        try {
	    String var=null;

	    System.out.print(var.charAt(3));
	    }

	    catch(Exception e)
	    {
	        System.out.print(e);
	    }
	    }
	}

//example 2



	
	
