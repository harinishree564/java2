package project1;

public class avg {
	public static void main(String[] args) {

	    
	    double num1 = 10;
	    double num2 = 15;
	    double num3 = 20;
        double num4 = 10;
        double num5 = 20;
        
	   
	    double sum = 0.0;
	    
	    double avg = 0.0;

	    
	    sum = num1 + num2 + num3 + num4 + num5;
	    		
	    
	    avg = sum/5;

	    // display result
	    System.out.println("Average: " + avg );
	  }
	}


