package project1;

public class andor {
	public static void main(String aa[])
    {
       int a=5;

         if(a % 2 ==0)
         {
            System.out.print("a is even"); 
         }
         else {
             System.out.print("a is odd"); 

         }



    }



}

