package project1;

public class call {
	public static void main(String aa[])
    {
		int  calls = 250, bill;
		if (calls>100 && calls<200)
			System.out.println("call is rupees 1/call");
		else if(calls>200 && calls<300)
		{
			bill=(n-100)*1;
		}
System.out.println("call is rupees 2/call");
		
		else if(calls>300 && calls<400)
			System.out.println("call is rupees 3/call");
    }
}
