package project1;

public class sum100 {
	public static void main(String aa[])
    {
	int num=100,i=2,evenSum = 0;
	while(i<=num) {
	evenSum = evenSum +i;
	i = i+2;
	}
	System.out.println("\n Sum of Even numbers upto" +num+ " = " +evenSum);
	}
	}

   



