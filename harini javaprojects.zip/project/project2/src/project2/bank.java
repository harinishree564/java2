package project2;

import java.util.Scanner;

public class bank {


class transaction {
	void accountNumber() {
		Scanner sc=new Scanner(System.in);
		int accnum;
		System.out.println("Enter the accnum ");
		accnum=sc.nextInt();
	}
}
}
