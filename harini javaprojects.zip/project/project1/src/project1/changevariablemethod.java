package project1;

public class changevariablemethod {

	

​​​​​

	String name,rollno;

	void setName(String name)

	{​​​​​

	    this.name=name;

	}​​​​​ 
	void setRollno(String rollno)

	{​​​​​

	    this.rollno=rollno;    

	}​​​​​ 
	String getName()

	{​​​​​

	    return name;

	}​​​​​ 
      getRollno()

	{​​​​​

	    return rollno;

	}​​​​​ ​​​​​

	
​​​​​

	    public static void main(String aa[])

	    {​​​​​

	         changevariablemethod t1=new changevariablemethod();

	          t1.setName("Sakshi");

	          t1.setRollno("23");

	          System.out.print(t1.getName()+"  "+t1.getRollno());

	}​​​​​

	}​​​​​


		  
		 
		 
	 
}
