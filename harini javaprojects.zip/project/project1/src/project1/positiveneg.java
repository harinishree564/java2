package project1;

public class positiveneg {
	public static void main(String aa[])
    {
       int a=-56;

         if(a > 0 )
         {
            System.out.print("a is positive"); 
         }
         else {
             System.out.print("a is negative"); 

         }



    }



}


